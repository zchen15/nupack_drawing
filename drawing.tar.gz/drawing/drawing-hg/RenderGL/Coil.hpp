// Coil Cointainer class
#include <map>
#include "Objects.h"
using namespace std;

typedef pair<const int, Object> intMap;
class Coil{
  private:
    map<int,Object> objList;
  public:
  Coil::Coil(){
  }
}
