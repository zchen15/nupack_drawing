package org.nupack.nudraw;

public interface Indexable {

	public Integer getIndex();

	public void setIndex(Integer index);
	
}
