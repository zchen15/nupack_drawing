package org.nupack.nudraw;

/**
 * Used during parsing. Each Strand is a distinct chain of Bases.
 * 1 or more Strands form a Sequence.
 * @author mbp
 *
 */
public class Strand extends BaseCollection {

}
