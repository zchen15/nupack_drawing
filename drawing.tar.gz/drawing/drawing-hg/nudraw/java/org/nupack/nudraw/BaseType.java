package org.nupack.nudraw;

public enum BaseType {
	STRAND_START,
	STRAND_END,
	PAIR_LEFT,
	PAIR_RIGHT,
	UNPAIRED
}
