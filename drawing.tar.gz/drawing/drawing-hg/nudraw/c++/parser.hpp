#ifndef PARSER_HPP
#define PARSER_HPP

namespace nudraw
{
    class parser
    {
        public:
        
        explicit parser();
        
        private:
    };
    
}
#endif        //  #ifndef PARSER_HPP

